export interface ClienteFacturacionInterface{
    id: number;
    id_evento: number;
    id_cliente: number;
    nombres: string;
    cedula: string;
    email: string;
    id_pais: number
}