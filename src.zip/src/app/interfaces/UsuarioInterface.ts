export interface UsuarioInterface {
    id: number,
    email: string,
    password: string,
    Transaccion: string,
}