export interface ComentarioInterface { 
    id: number;
    mensaje: string;
    Transaccion: string;
}