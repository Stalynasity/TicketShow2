export interface DetalleInterface{
    id: number;
    cantidad: number;
    precio_final: number;
    id_evento: number;
    id_factura: number;
}