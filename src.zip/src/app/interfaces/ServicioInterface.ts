export interface ServicioInterface{

    id: number;
    nombre: string;
    tipo_evento: string;
    nombre_organizador: string;
    email: string;
    pos_lugar: string;
    id_ciudad: number;
    Transaccion: string;
}