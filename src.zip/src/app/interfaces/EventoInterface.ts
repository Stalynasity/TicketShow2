
export interface EventoInterface {

    titulo: string;
    descripcion: string;
    participantes: string;
    cupos: number;
    fecha: string;
    Transaccion: string;
    localidad: string;
    precio: string;
    lugar: any;
    hora: string;
    img: string;
    nombre: string;
    direccion: string;
}