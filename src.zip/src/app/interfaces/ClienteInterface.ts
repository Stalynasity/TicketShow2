export interface ClienteInterface { 
    id: number;
    cedula: string;
    nombre: string;
    apellido: string;
    direccion: string;
    telefono: number;
    fecha_nacimiento: Date;
    Transaccion: string;
}