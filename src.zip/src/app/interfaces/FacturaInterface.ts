export interface FacturaInterface{
    id: number;
    fecha: Date;
    id_cliente_facturacion: number;
}