export interface FormaPagoInterface{
    id: number;
    nombre: string;
    id_factura: number;
}