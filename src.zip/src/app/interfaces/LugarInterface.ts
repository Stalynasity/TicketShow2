export interface LugarInterface { 
    id: string;
    nombre: string;
    direccion: string;
    id_ciudad: string;
}