export interface ClienteInterface {

    nombres: string;
}